import re
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_circles
import pandas as pd

import info_list


def write(china_total, province_list):
    calendar_list = china_total.daily_diagnosis.keys()
    calendar = []
    for day in calendar_list:
        calendar.append(day)

    daily_diagnosis = pd.DataFrame(columns=['大陆总计'] + [*info_list.province_names], index=[*calendar])

    for key in province_list.keys():
        for date in province_list[key].daily_diagnosis:
            daily_diagnosis.loc[date, key] = province_list[key].daily_diagnosis[date]

    for key in china_total.daily_diagnosis.keys():
        daily_diagnosis.loc[key, '大陆总计'] = china_total.daily_diagnosis[key]

        days = re.findall(r"(\d+)月(\d+)日", key)
        index = 100 * (int(days[0][0])) + int(days[0][1])
        daily_diagnosis.loc[key, 'index'] = index

    daily_diagnosis.fillna(0, inplace=True)

    # 第二张表

    daily_asymptomatic = pd.DataFrame(columns=['大陆总计'] + [*info_list.province_names], index=[*calendar])
    for key in province_list.keys():
        for date in province_list[key].daily_asymptomatic:
            daily_asymptomatic.loc[date, key] = province_list[key].daily_asymptomatic[date]

    for key in china_total.daily_asymptomatic.keys():
        daily_asymptomatic.loc[key, '大陆总计'] = china_total.daily_asymptomatic[key]

        days = re.findall(r"(\d+)月(\d+)日", key)
        index = 100 * (int(days[0][0])) + int(days[0][1])
        daily_asymptomatic.loc[key, 'index'] = index

    daily_asymptomatic.fillna(0, inplace=True)

    # daily_asymptomatic.to_csv("daily_asymptomatic.csv",encoding='GBK')
    # daily_asymptomatic.to_excel("daily_asymptomatic.xlsx",encoding='GBK',sheet_name="daily_asymptomatic")
    daily_diagnosis.sort_values(by="index", ascending=False, inplace=True)
    daily_asymptomatic.sort_values(by="index", ascending=False, inplace=True)

    daily_diagnosis.drop('index', axis=1, inplace=True)
    daily_asymptomatic.drop('index', axis=1, inplace=True)

    buffer = daily_diagnosis.iloc[:, 33:]
    buffer = buffer.diff(periods=-1)
    daily_diagnosis = daily_diagnosis.drop(['香港', "澳门", "台湾"], axis=1)
    daily_diagnosis = pd.concat([daily_diagnosis, buffer], axis=1)
    print(buffer)

    daily_asymptomatic = daily_asymptomatic.drop(['香港', "澳门", "台湾"], axis=1)

    with pd.ExcelWriter('./data.xlsx') as writer:
        daily_diagnosis.to_excel(writer, sheet_name='每日确诊', index=True)
        daily_asymptomatic.to_excel(writer, sheet_name='每日无症状', index=True)
    return daily_diagnosis, daily_asymptomatic

def newupdate():
    X_circle, Y_circle = make_circles(n_samples=400, noise=0.1, factor=0.1)
    n = np.random.randint(0, 10, size=1)
    ran = random.random()
    x = pow(-1, n) * ran
    n = np.random.randint(0, 10, size=1)
    ran = random.random()
    y = pow(-1, n) * ran
    print(x, y)
    plt.subplot(1, 2, 1)
    plt.scatter(X_circle[:, 0], X_circle[:, 1], s=100, marker="o", edgecolors='m', c=Y_circle)
    plt.title('data by make_circles()')
    plt.scatter(x, y, s=300, marker="*", edgecolors='black', c='red')
    plt.subplot(1, 2, 2)
    plt.scatter(X_circle[:, 0], X_circle[:, 1], s=100, marker="o", edgecolors='m', c=Y_circle)
    plt.scatter(x, y, s=300, marker="*", edgecolors='black', c='red')
    plt.title('KNN(k=15)')
    data = {'x坐标': X_circle[:, 0], 'y坐标': X_circle[:, 1], }
    olddata = pd.DataFrame(data, dtype='double')
    new_x_y = [float(x), float(y)]
    distance = (((olddata - new_x_y) ** 2).sum(1)) ** 0.5  # 得到((x1-x2)^2+(y1-y2)^2)^0.5
    disdata = pd.DataFrame({'x坐标': X_circle[:, 0], 'y坐标': X_circle[:, 1], '距离': distance},
                           dtype='double').sort_values(by='距离')
    k = 15
    plt.scatter(disdata.iloc[:k, 0], disdata.iloc[:k, 1], s=100, marker="o", edgecolors='black', c='red')